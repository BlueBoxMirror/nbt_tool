import { Parser } from "./Parser";
import { StringReader } from "./StringReader";

export class Util{
    /**
     * 转换NBT类型为字符串
     * @param nbtType NBT类型(int)
     * @returns NBT类型字符串
     */
    public static typeToString(nbtType:Number):string{
        switch(nbtType){
            case NBT.Byte:
                return "Byte";
            case NBT.ByteArray:
                return "ByteArray";
            case NBT.Compound:
                return "Compound";
            case NBT.Double:
                return "Double";
            case NBT.End:
                return "End";
            case NBT.Float:
                return "Float";
            case NBT.Int:
                return "Int";
            case NBT.List:
                return "List";
            case NBT.Long:
                return "Long";
            case NBT.Short:
                return "Short";
            case NBT.String:
                return "String";
            default:
                return "Unknow";
        }
    }
    /**
     * NBT转换为SNBT字符串
     * @param nbt NBT 
     * @returns SNBT字符串
     */
    public static toSNBT(rawNbt:NbtType):string{
        let str='';
        switch(rawNbt.getType()){
            case NBT.Compound:{
                const nbt=<NbtCompound>rawNbt;
                str+='{';
                nbt.getKeys().forEach(key=>{
                    str+='"'+key+'":'+this.toSNBT(nbt.getTag(key)!)+',';
                })
                return str.substring(0,str.length-1)+'}'
            }
            case NBT.List:{
                const nbt=<NbtList>rawNbt;
                str+='[';
                for(let i=0;i<nbt.getSize();i++){
                    str+=this.toSNBT(nbt.getTag(i)!)+',';
                }
                return str.substring(0,str.length-1)+']'
            }
            case NBT.String:{
                const nbt=<NbtString>rawNbt;
                let str=nbt.get().replace(/\\\\n/gm,'\\n');
                str=nbt.get().replace(/\\\\"/gm,'\\"');
                str=nbt.get().replace(/\\\\'/gm,"\\'");
                str=nbt.get().replace(/\\\\\\\\/gm,'\\\\');
                return '"'+str+'"';
            }
            case NBT.Byte:
                return (<NbtByte>rawNbt).get()+'b';
            case NBT.Int:
                return (<NbtInt>rawNbt).get()+'';
            case NBT.Short:
                return (<NbtShort>rawNbt).get()+'s';
            case NBT.Long:
                return (<NbtByte>rawNbt).get()+'l';
            case NBT.Float:
                return (<NbtByte>rawNbt).get()+'f';
            case NBT.Double:
                return (<NbtByte>rawNbt).get()+'';
        }
        throw new Error('错误的NBT');
    }
    /**
     * SNBT字符串转换为NBT
     * @param snbt SNBT字符串 
     * @returns NBT
     */
    public static parseSNBT(snbt:string):NbtType{
        return Parser.parseValue(new StringReader(snbt));
    }
    /**
     * 将容器对象转换为NBTList序列
     * @param container 容器
     * @returns NBTList序列
     */
    public static containerToNbt(container:Container):NbtList{
        const list=new NbtList([]);
        container.getAllItems().forEach(item=>{
            list.addTag(item.getNbt());
        })
        return list;
    }
    /**
     * 将NBTList序列传至容器对象
     * @param container 原容器对象
     * @param nbt NBTList序列
     */
    public static nbtToContainer(container:Container,nbt:NbtList){
        for(let i=0;i<nbt.getSize();i++){
            container.setItem(i,<Item>mc.newItem(<NbtCompound>nbt.getTag(i)));
        }
    }
}
import { StringReader } from "./StringReader";

export class Parser{
    public static parseNumberNbt(reader:StringReader):NbtInt|NbtByte|NbtFloat|NbtDouble|NbtShort|NbtLong{
        let num=0;
        let point=false;
        let times=0.1;
        while(reader.hasNext()){
            const ch=reader.next();
            switch(ch){
                case 's':
                    return new NbtShort(num);
                case 'b':
                    return new NbtByte(num);
                case 'l':
                    return new NbtLong(num);
                case 'f':
                    return new NbtFloat(num);
                case '.':
                    if(point) throw new Error('数字格式错误');
                    point=true;
                break;
                case '0':
                    if(point){
                        num=num+0*times
                        times*=0.1;
                    }
                    else num=num*10+0;
                break;
                case '1':
                    if(point){
                        num=num+1*times
                        times*=0.1;
                    }
                    else num=num*10+1;
                break;
                case '2':
                    if(point){
                        num=num+2*times
                        times*=0.1;
                    }
                    else num=num*10+2;
                break;
                case '3':
                    if(point){
                        num=num+3*times
                        times*=0.1;
                    }
                    else num=num*10+3;
                break;
                case '4':
                    if(point){
                        num=num+4*times
                        times*=0.1;
                    }
                    else num=num*10+4;
                break;
                case '5':
                    if(point){
                        num=num+5*times
                        times*=0.1;
                    }
                    else num=num*10+5;
                break;
                case '6':
                    if(point){
                        num=num+6*times
                        times*=0.1;
                    }
                    else num=num*10+6;
                break;
                case '7':
                    if(point){
                        num=num+7*times
                        times*=0.1;
                    }
                    else num=num*10+7;
                break;
                case '8':
                    if(point){
                        num=num+8*times
                        times*=0.1;
                    }
                    else num=num*10+8;
                break;
                case '9':
                    if(point){
                        num=num+9*times
                        times*=0.1;
                    }
                    else num=num*10+9;
                break;
            }
        }
        return point?new NbtDouble(num):new NbtInt(num);
    }
    public static parseString(reader:StringReader):string{
        reader.skipWarp();
        let str='';
        if(reader.next()=='"'){
            while(reader.hasNext()){
                const ch=reader.next();
                if(ch=='"'){
                    return str;
                }
                else if(ch=='\\'){
                    switch(reader.next()){
                        case 'n':
                            str+='\n';
                            break;
                        case '\\':
                            str+='\\';
                            break;
                        case '"':
                            str+='"';
                            break;
                        case "'":
                            str+="'";
                            break;
                        default:
                            throw new Error('错误的转义');
                    }
                }
                else{
                    str+=ch;
                }
            }
        }
        throw new Error('格式错误:s '+reader.toString());
    }
    public static parseCompound(reader:StringReader):NbtCompound{
        const nbt=new NbtCompound({});
        if(reader.next()=='{'){
            while(reader.hasNext()){
                reader.skipWarp();
                const ch=reader.next();
                if(ch=='}') return nbt;
                else if(ch=='"'){
                    reader.left();
                    const key=this.parseString(reader);
                    reader.skipWarp();
                    if(reader.next()!=':') throw new Error('格式错误:pc A '+reader.toString());
                    nbt.setTag(key,this.parseValue(reader));
                    reader.skipWarp();
                    const ch1=reader.next();
                    if(ch1==','){}
                    else if(ch1=='}') return nbt;
                    else throw new Error('格式错误:pc B '+reader.toString());
                }
            }
        }
        throw new Error('格式错误:pc C '+reader.toString() );
    }
    public static parseList(reader:StringReader):NbtList{
        const nbt=new NbtList([]);
        if(reader.next()=='['){
            while(reader.hasNext()){
                reader.skipWarp();
                const ch=reader.next();
                if(ch==']') return nbt;
                else{
                    reader.left();
                    nbt.addTag(this.parseValue(reader));
                    reader.skipWarp();
                    const ch1=reader.next();
                    if(ch1==','){}
                    else if(ch1==']') return nbt;
                    else throw new Error('格式错误:pc B '+reader.toString()); 
                }
            }
        }
        throw new Error('格式错误:pl '+reader.toString());
    }
    public static parseValue(reader:StringReader):NbtType{
        reader.skipWarp();
        const ch=reader.peek();
        switch(ch){
            case '"':
                return new NbtString(this.parseString(reader));
            case '0':
            case '1':
            case '2':
            case '3':
            case '4':
            case '5':
            case '6':
            case '7':
            case '8':
            case '9':
                return this.parseNumberNbt(reader);
            case '[':
                return this.parseList(reader);
            case '{':
                return this.parseCompound(reader);
            default:
                throw new Error('格式错误:v '+reader.toString());
        }
    }

}
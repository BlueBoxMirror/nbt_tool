export class StringReader{
    public constructor(str:string){
        this.str=str;
    }
    public readonly str:string;
    private index=0;
    public hasNext(){
        return this.index<this.str.length
    }
    public next(){
        return this.str.charAt(this.index++);
    }
    public peek(){
        return this.str.charAt(this.index);
    }
    public left(step=1){
        this.index-=step;
    }
    public right(step=1){
        this.index+=step;
    }
    public toString(){
        return '<'+this.str+'>['+this.index+']'
    }
    public skipWarp(){
        while(true){
            switch(this.str.charAt(this.index)){
                case ' ':
                case '\n':
                    this.index++;
                    break;
                default:
                    return;
            }
        }
    }
}